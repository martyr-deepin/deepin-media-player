#! /usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) 2011 ~ 2012 Deepin, Inc.
#               2011 ~ 2012 Hai longqiu.
# 
# Author:     Hai longqiu <qiuhailong@linuxdeepin.com>
# Maintainer: Hai longqiu <qiuhailong@linuxdeepin.com>
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from skin import app_theme
from dtk.ui.dialog import DialogBox, DIALOG_MASK_MULTIPLE_PAGE
# from dtk.ui.treeview import TreeView
# from dtk.ui.progressbar import ProgressBar
from new_progressbar import NewProgressBar as ProgressBar

import gtk

FORM_WIDTH  = 300
FORM_HEIGHT = 400

class ConvTAskGui(DialogBox):
    def __init__(self):
        DialogBox.__init__(self, 
                           "格式转化任务管理器", 
                           FORM_WIDTH, FORM_HEIGHT, 
                           mask_type=DIALOG_MASK_MULTIPLE_PAGE,
                           modal=False,
                           window_hint=gtk.gdk.WINDOW_TYPE_HINT_DIALOG,
                           window_pos=gtk.WIN_POS_CENTER,
                           resizable=False
                           )                                
        # add event.
        self.connect("destroy", lambda w : gtk.main_quit())        
        self.init_widgets()
        # add widgets.
        self.body_box.pack_start(self.progressbar, False, False)
        
    def init_widgets(self):    
        self.progressbar = ProgressBar()
        
if __name__ == "__main__":
    conv_task_gui = ConvTAskGui()
    conv_task_gui.show_all()
    gtk.main()    
    
